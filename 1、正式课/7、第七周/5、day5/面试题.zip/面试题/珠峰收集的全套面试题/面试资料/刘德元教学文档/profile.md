title: 分享
speaker: 刘德元
theme: colors
usemathjax: yes

[slide data-transition="cards"]
# HELLO

[slide data-transition="cards"]

### 主人公
![image](http://p1.bpimg.com/567571/3041ff3c713d4571.jpg)


[slide data-transition="cards"]
### 基本资料、主人公背（bei）景（ying）
- 姓名： 略
- 年龄：略
- 籍贯：山西阳泉
- 爱好：打dota=>写代码。
- 擅长：打dota，但是不擅长写代码。。。
- 特别擅长：修理电脑。。。。


[slide data-transition="zoomin"]
# 前端不归路
> 论一个欢（ruo）乐（zhi）青(er)年(tong)是如何走上前端不归路的


[slide data-transition="vertical3d"]
### eloquentjavascript
![image](http://p1.bqimg.com/4851/925d8b7d65b5e8da.png)

[eloquentjavascript](http://eloquentjavascript.net/)
[slide data-transition="vertical3d"]
### freecodecamp
![image](http://p1.bqimg.com/4851/5e6a67e9707f7384.png)
[freecodecamp](https://www.freecodecamp.com/)
[slide data-transition="vertical3d"]
### javascript高级程序设计
![image](http://p1.bpimg.com/4851/7951faeee912c488.jpg)

[javascript高级程序设计](https://www.nczonline.net/)
[slide data-transition="vertical3d"]
### 项目驱动
![image](http://p1.bpimg.com/4851/ca08d45bd26ea1d3.jpg)
[slide data-transition="zoomin"]
# 技（chui）术(niu)
[slide data-transition="zoomout"]
### Nginx
![image](http://i1.piimg.com/567571/7d443896fa2b67c9.png)
[slide data-transition="zoomin"]
### 具体配置
```
location ~ .*\.(gif|jpg|jpeg|bmp|png|ico|txt|js|css)$ {
    proxy_pass http://192.168.2.72:8888;
}
location ~ /admin/api/ {
    proxy_pass http://192.168.2.147:8080;
}
```
[slide data-transition="zoomin"]
# 思（hu）考(shuo)

[slide data-transition="zoomin"]
### 关于正则的懒惰
![](http://p1.bqimg.com/567571/a3028f8e5f5a9344.png)
[slide data-transition="zoomin"]
### 关于正则的贪婪
![](http://p1.bqimg.com/567571/37ebb086a093f355.png)
[slide data-transition="zoomin"]
![](http://p1.bqimg.com/567571/b15bd5835b716642.jpg)

[slide data-transition="zoomin"]
### 第一集
### （完）
#    谢谢大家！